# Adapters & Live Data Connectors

Place adapter modules in `app/src/adapters/`. Each adapter should export the following interface:

```js
export default function createAdapter({ onCandle }) {
  return {
    connect: async (config) => { /* open websocket / auth */ },
    subscribe: (symbol, timeframe) => { /* call onCandle(candle) when new candle arrives */ },
    placeOrder: async (order) => { /* if adapter supports trading */ },
    disconnect: async () => { /* cleanup */ }
  };
}
```

Example adapter candidates:
- `binanceAdapter.js` — uses Binance WebSocket for kline streams.
- `finnhubAdapter.js` — uses Finnhub websocket for forex/stocks.
- `oandaAdapter.js` — REST + streaming for forex orders (requires brokerage account).

Security note: For order placement prefer a server-side adapter to avoid embedding credentials in client-side builds.

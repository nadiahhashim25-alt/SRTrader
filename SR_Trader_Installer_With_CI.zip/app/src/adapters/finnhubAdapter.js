/**
 * finnhubAdapter.js
 * - Connects to Finnhub websocket for real-time candles/trades (requires API key)
 * - Usage: const a = createAdapter({ onCandle }); await a.connect({ apiKey: 'YOUR_KEY' }); a.subscribe('OANDA:EUR_USD', '1m');
 */
export default function createAdapter({ onCandle }) {
  let ws = null;
  let apiKey = null;
  function connect({ apiKey: key }) {
    apiKey = key;
    if (!apiKey) throw new Error('Finnhub requires apiKey in connect()');
    ws = new WebSocket(`wss://ws.finnhub.io?token=${apiKey}`);
    ws.onopen = () => console.log('Finnhub WS connected');
    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.type === 'trade' && msg.data) {
          // Finnhub trade messages can be aggregated to candles client-side
          // For demo, we skip aggregation; production: aggregate trades into OHLC per timeframe
        } else if (msg.type === 'ping') {
          // ignore
        }
      } catch (e) { console.error('finnhub parse', e); }
    };
    ws.onclose = () => console.log('Finnhub WS closed');
    ws.onerror = (e) => console.error('Finnhub WS error', e);
    return Promise.resolve();
  }

  function subscribe(symbol, timeframe='1m') {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.warn('Finnhub WS not open — call connect() first');
      return;
    }
    ws.send(JSON.stringify({ type: 'subscribe', symbol }));
    // Note: Finnhub provides trade streams; convert to candlesticks client-side
  }

  function unsubscribe(symbol) {
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'unsubscribe', symbol }));
  }

  async function disconnect() {
    if (ws) try { ws.close(); } catch(e) {}
    ws = null;
  }

  return { connect, subscribe, unsubscribe, disconnect };
}

/**
 * binanceAdapter.js
 * - Connects to Binance public websocket kline streams and calls onCandle with OHLC bars
 * - Usage: const a = createAdapter({ onCandle }); await a.connect(); a.subscribe('btcusdt', '1m');
 */
export default function createAdapter({ onCandle }) {
  let ws = null;
  let subscriptions = new Set();

  function buildStreamSymbol(sym, tf) {
    // Binance uses lowercase symbol and kline interval like 1m,5m,1h
    return `${sym.toLowerCase()}@kline_${tf}`;
  }

  async function connect() {
    // no auth required for public market data
    ws = new WebSocket('wss://stream.binance.com:9443/ws');
    ws.onopen = () => console.log('Binance WS connected');
    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.e === 'kline') {
          const k = msg.k;
          const candle = {
            time: Math.floor(k.t / 1000),
            open: Number(k.o),
            high: Number(k.h),
            low: Number(k.l),
            close: Number(k.c),
            volume: Number(k.v)
          };
          // only send completed candles (k.x === true) or you can send partial updates
          if (k.x) onCandle && onCandle(candle);
        }
      } catch (e) { console.error('binance parse', e); }
    };
    ws.onclose = () => console.log('Binance WS closed');
    ws.onerror = (e) => console.error('Binance WS error', e);
  }

  function subscribe(symbol, timeframe='1m') {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      // wait until connect (user should connect first), or we can buffer but keep simple
      console.warn('Binance WS not open — call connect() first');
      return;
    }
    const stream = buildStreamSymbol(symbol, timeframe);
    ws.send(JSON.stringify({ method: 'SUBSCRIBE', params: [stream], id: Date.now() }));
    subscriptions.add(stream);
  }

  function unsubscribe(symbol, timeframe='1m') {
    const stream = buildStreamSymbol(symbol, timeframe);
    subscriptions.delete(stream);
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ method: 'UNSUBSCRIBE', params: [stream], id: Date.now() }));
  }

  async function disconnect() {
    if (ws) {
      try { ws.close(); } catch(e) {}
      ws = null;
    }
  }

  return { connect, subscribe, unsubscribe, disconnect };
}

/**
 * oandaAdapter.js (skeleton)
 * - Server-side integration recommended. This client-side adapter shows method signatures.
 * - For real trading, create a secure backend proxy that holds API credentials.
 */
export default function createAdapter({ onUpdate }) {
  let config = null;
  function connect(cfg) {
    config = cfg; // expect { token, accountId, baseUrl }
    // DO NOT store tokens unencrypted for production
    console.log('OANDA adapter configured (skeleton)'); 
    return Promise.resolve();
  }
  async function placeOrder(order) {
    // order: { symbol, side, units, type, price, tif }
    // In production call your backend proxy which calls OANDA REST API
    throw new Error('placeOrder requires server-side implementation');
  }
  async function getPositions() {
    return []; // fetch from server-side
  }
  async function disconnect() {}
  return { connect, placeOrder, getPositions, disconnect };
}

/**
 * binanceRestAdapter.js (skeleton)
 * - For order placement use server-side signed REST calls to Binance
 * - This client adapter will call your backend proxy endpoints
 */
export default function createAdapter({ apiBase }) {
  async function placeOrder(order) {
    // POST to your server which signs and forwards to Binance REST API
    const res = await fetch(`${apiBase}/broker/binance/placeOrder`, { method: 'POST', body: JSON.stringify(order), headers: {'Content-Type':'application/json'} });
    return res.json();
  }
  return { placeOrder };
}

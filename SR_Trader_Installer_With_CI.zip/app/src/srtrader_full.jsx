import React, { useEffect, useRef, useState } from 'react';
import { createChart, CrosshairMode } from 'lightweight-charts';
import createBinanceAdapter from './adapters/binanceAdapter';
import createFinnhubAdapter from './adapters/finnhubAdapter';

function computeRSI(data, length=14) {
  const out = [];
  let gains=0, losses=0;
  for (let i=1;i<data.length;i++) {
    const change = data[i].close - data[i-1].close;
    if (i <= length) {
      if (change>=0) gains+=change; else losses+=Math.abs(change);
      if (i===length) out.push(100 - 100/(1 + gains/(losses||1e-9)));
      else out.push(null);
    } else {
      gains = (gains*(length-1) + (change>0?change:0))/length;
      losses = (losses*(length-1) + (change<0?Math.abs(change):0))/length;
      out.push(100 - 100/(1 + gains/(losses||1e-9)));
    }
  }
  out.unshift(null);
  return out;
}

export default function SRTraderFull() {
  const chartRef = useRef(null);
  const chartObj = useRef(null);
  const candleSeries = useRef(null);
  const lineSeries = useRef(null);
  const rsiSeries = useRef(null);
  const [connected, setConnected] = useState(false);
  const [adapterName, setAdapterName] = useState('binance');
  const adapterRef = useRef(null);
  const [symbol, setSymbol] = useState('btcusdt');
  const [timeframe, setTimeframe] = useState('1m');
  const [status, setStatus] = useState('idle');
  const [chartType, setChartType] = useState('candlestick'); // 'candlestick' | 'line' | 'bar' | 'heikin'
  const lastDataRef = useRef([]);

  useEffect(() => {
    const el = chartRef.current;
    if (!el) return;
    el.innerHTML = '';
    const chart = createChart(el, { width: el.clientWidth, height: 520, layout: { backgroundColor: '#071226', textColor: '#f0e9d8' }, grid: { vertLines: { color: '#0b1622' }, horzLines: { color: '#0b1622' } }, crosshair: { mode: CrosshairMode.Normal } });
    chartObj.current = chart;
    candleSeries.current = chart.addCandlestickSeries({ upColor: '#ffd166', downColor: '#c94a4a', wickUpColor: '#ffd166', wickDownColor: '#c94a4a' });
    lineSeries.current = chart.addLineSeries({ color: '#8ab4ff', lineWidth: 1 });
    // RSI as separate pane: create a histogram-ish with its own scaleMargins
    rsiSeries.current = chart.addLineSeries({ color: '#f4c542', lineWidth: 1, priceScaleId: 'rsi', scaleMargins: { top: 0.75, bottom: 0 } });
    const ro = new ResizeObserver(() => chart.applyOptions({ width: el.clientWidth }));
    ro.observe(el);
    return () => { ro.disconnect(); chart.remove(); };
  }, []);

  function toHeikinAshi(data) {
    const out = [];
    for (let i=0;i<data.length;i++) {
      const o = data[i].open, h = data[i].high, l = data[i].low, c = data[i].close;
      if (i===0) {
        out.push({ time: data[i].time, open: o, high: h, low: l, close: c });
      } else {
        const prev = out[i-1];
        const haClose = (o+h+l+c)/4;
        const haOpen = (prev.open + prev.close)/2;
        const haHigh = Math.max(h, haOpen, haClose);
        const haLow = Math.min(l, haOpen, haClose);
        out.push({ time: data[i].time, open: Number(haOpen.toFixed(2)), high: Number(haHigh.toFixed(2)), low: Number(haLow.toFixed(2)), close: Number(haClose.toFixed(2)) });
      }
    }
    return out;
  }

  function updateChartWithData(arr) {
    lastDataRef.current = arr.slice(-500);
    if (chartType === 'heikin') {
      const ha = toHeikinAshi(lastDataRef.current);
      candleSeries.current.setData(ha);
      lineSeries.current.setData([]);
    } else if (chartType === 'candlestick') {
      candleSeries.current.setData(lastDataRef.current);
      lineSeries.current.setData([]);
    } else if (chartType === 'line') {
      lineSeries.current.setData(lastDataRef.current.map(d => ({ time: d.time, value: d.close })));
      candleSeries.current.setData([]);
    } else if (chartType === 'bar') {
      // represent bar via candlestick but styled thinner
      candleSeries.current.setData(lastDataRef.current);
      lineSeries.current.setData([]);
    }
    // compute RSI and plot on rsiSeries (normalize to 0-100)
    const rsi = computeRSI(lastDataRef.current, 14).map((v, idx) => v ? ({ time: lastDataRef.current[idx].time, value: Number(v.toFixed(2)) }) : null).filter(Boolean);
    if (rsi.length) rsiSeries.current.setData(rsi); else rsiSeries.current.setData([]);
  }

  function onCandle(candle) {
    try {
      if (!candle || !candle.time) return;
      const arr = lastDataRef.current.slice();
      // append or replace last
      if (arr.length && arr[arr.length-1].time === candle.time) arr[arr.length-1] = candle; else arr.push(candle);
      if (arr.length > 1200) arr.shift();
      updateChartWithData(arr);
    } catch (e) { console.error('onCandle', e); }
  }

  async function connectAdapter(name) {
    setStatus('connecting');
    try { if (adapterRef.current && adapterRef.current.disconnect) await adapterRef.current.disconnect(); } catch(e){}
    adapterRef.current = null;
    if (name === 'binance') {
      const a = createBinanceAdapter({ onCandle });
      adapterRef.current = a;
      await a.connect();
      a.subscribe(symbol, timeframe);
      setConnected(true); setStatus('connected to Binance');
    } else if (name === 'finnhub') {
      const a = createFinnhubAdapter({ onCandle });
      adapterRef.current = a;
      let cfg = {};
      try { const res = await fetch('/config.json'); cfg = await res.json(); } catch(e) { console.warn('No config.json'); }
      await a.connect({ apiKey: cfg.FINNHUB_API_KEY });
      a.subscribe(symbol, timeframe);
      setConnected(true); setStatus('connected to Finnhub');
    }
  }

  function disconnectAdapter() {
    try { adapterRef.current && adapterRef.current.disconnect(); } catch(e){}
    adapterRef.current = null; setConnected(false); setStatus('disconnected');
  }

  function changeSymbol(sym) {
    setSymbol(sym);
    try { if (adapterRef.current && adapterRef.current.subscribe) adapterRef.current.subscribe(sym, timeframe); } catch(e){}
  }

  function changeTF(tf) {
    setTimeframe(tf);
    try { if (adapterRef.current && adapterRef.current.subscribe) adapterRef.current.subscribe(symbol, tf); } catch(e){}
  }

  function changeChartType(t) {
    setChartType(t);
    // refresh chart with current data
    updateChartWithData(lastDataRef.current || []);
  }

  return (
    <div style={{ padding: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <img src='/icon-256.png' alt='SR' style={{ width: 48, height: 48 }} />
          <h2 style={{ margin:0 }}>SR Trader — Live Demo</h2>
        </div>
        <div>
          <select value={adapterName} onChange={(e) => setAdapterName(e.target.value)}>
            <option value="binance">Binance (crypto & futures)</option>
            <option value="finnhub">Finnhub (forex/stocks)</option>
          </select>
          {connected ? <button onClick={disconnectAdapter} style={{ marginLeft: 8 }}>Disconnect</button> : <button onClick={() => connectAdapter(adapterName)} style={{ marginLeft: 8 }}>Connect</button>}
        </div>
      </div>

      <div style={{ marginTop: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
        <label>Symbol:</label>
        <input value={symbol} onChange={(e)=>setSymbol(e.target.value)} />
        <label>TF:</label>
        <select value={timeframe} onChange={(e)=>changeTF(e.target.value)}>
          <option value="1m">1m</option>
          <option value="5m">5m</option>
          <option value="15m">15m</option>
          <option value="1h">1h</option>
        </select>
        <label>Chart:</label>
        <select value={chartType} onChange={(e)=>changeChartType(e.target.value)}>
          <option value="candlestick">Candlestick</option>
          <option value="line">Line</option>
          <option value="heikin">Heikin Ashi</option>
          <option value="bar">Bar</option>
        </select>
        <span style={{ marginLeft: 12 }}>{status}</span>
      </div>

      <div ref={chartRef} style={{ width: '100%', height: 520, marginTop: 12 }} />

      <div style={{ marginTop: 12 }}>
        <p>Notes: Untuk Finnhub, letak API key dalam <code>/public/config.json</code>. Binance tidak perlu key untuk kline stream.</p>
      </div>
    </div>
  );
}

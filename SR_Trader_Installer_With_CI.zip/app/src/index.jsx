import React from 'react';
import { createRoot } from 'react-dom/client';
import SRApp from './SRApp';

const root = createRoot(document.getElementById('root'));
root.render(<SRApp />);

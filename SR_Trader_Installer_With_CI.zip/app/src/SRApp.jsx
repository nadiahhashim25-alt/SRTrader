import React from 'react';
import SRTraderFull from './srtrader_full.jsx';

export default function SRApp() {
  return (
    <div style={{ height: '100vh', background: '#071226', color: '#dff3ff' }}>
      <SRTraderFull />
    </div>
  );
}

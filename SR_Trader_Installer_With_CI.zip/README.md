# SR Trader — Starter (Electron + React)

This package is a starter **source bundle** for **SR Trader** (desktop app).  
It contains a React frontend (in `/app`) and minimal Electron glue so you can build a Windows installer yourself.

**What you get**
- React app (SR Trader frontend prototype) with charting and client-side indicators (SMA, EMA, RSI, MACD, Bollinger, Stochastic).
- Electron main + preload files to run as desktop app.
- README with build instructions and guidance to connect live market data from free APIs and to add broker adapters.

---

## Quick setup (on your PC)

1. Install Node.js (v18+ recommended) and Git.
2. On your PC, copy this folder to somewhere (or unzip `SR_Trader_Starter.zip`).
3. Open terminal in this folder and run:

```bash
# install Electron dev dependencies
npm install

# go into the React app and install dependencies
cd app
npm install

# start React dev server (in app)
npm run start
# in a new terminal window run:
npm run serve
```

The `serve` script runs Electron and loads the dev server (so the app opens in an installable window).

To build a production app and create an installer:
- Follow the README in `/app` that includes scripts for `electron-builder`.
- Typically:
```bash
cd app
npm run build
cd ..
npm run dist
```
(You'll need to configure `electron-builder` target and code signing for Windows builds.)

---

## Live market data (free APIs) — recommended options

- **Cryptocurrency futures / spot**: Binance WebSocket (wss://stream.binance.com:9443). Free, real-time. Use for BTC/ETH, and Binance USDT perpetual symbols.
- **Forex & Stocks (freemium)**:
  - Finnhub.io — free tier with API key; supports forex + stocks + crypto. (Some endpoints have rate limits.)
  - Twelve Data — free tier with limited requests.
- **Alternative**: use public websockets from crypto exchanges for cheap live tick data, then use conversion or aggregator for forex/futures.

**Notes about futures**: Many exchange-level futures (CME, ICE) are not freely available via public websockets; usually you get them from brokers or market-data vendors. For demo charts you can use aggregated CFD/crypto/fake futures.

---

## Broker connections (how to let users connect their own broker)

Design pattern:
- Provide a **Broker Adapter interface** in the app:
  - `connect(config)`, `subscribeMarket(symbol)`, `placeOrder(order)`, `cancelOrder(id)`, `getPositions()`.
- Ship built-in adapters for:
  - Binance (REST + WS)
  - OANDA (REST + streaming)
  - Alpaca (stocks)
- For sensitive actions (order placement) we recommend using a **backend proxy** to:
  - keep API keys off the client,
  - perform server-side risk checks,
  - provide audit logs and replay.
- But we also provide a local-only mode where user pastes their API key into the app (stored encrypted) to connect directly.

Security:
- Never store API keys unencrypted. For production, use OS secure storage (Windows Credential Vault / macOS Keychain).
- For order execution, strongly prefer server-side routing.

---

## Next steps I can do for you (choose one)
1. Prepare a complete repo inside this bundle including `app/` React source with the SR Trader component (I already prepared it) and instructions to build the `.exe` using `electron-builder`. I can include adapter skeletons for Binance & Finnhub.
2. Build the Windows `.exe` here and give you the binary (not possible in this environment due to platform limitations).
3. Help you connect to a free data source (I'll add code and a sample config for Binance / Finnhub).

Tell me which of the above you'd like — I can pack the full starter with adapter skeletons now.


## Included adapters & server proxy example
- app/src/adapters/binanceAdapter.js (crypto websockets)
- app/src/adapters/finnhubAdapter.js (forex/stocks, requires API key)
- app/src/adapters/oandaAdapter.js (broker skeleton)
- app/src/adapters/binanceRestAdapter.js (order routing skeleton)
- server/ (Node proxy example) with index.js and README


### Quick config for Finnhub
Copy `app/public/config.example.json` to `app/public/config.json` and add your FINNHUB_API_KEY.

## GitHub Actions CI for automatic Windows build

I included a GitHub Actions workflow at `.github/workflows/build-windows.yml`.  
Cara guna:

1. Buat repo baru di GitHub dan push semua fail dari folder ini ke repo (branch `main`).  
   - contoh (dalam folder projek):
     ```bash
     git init
     git add .
     git commit -m "Initial SR Trader project"
     git branch -M main
     git remote add origin https://github.com/USERNAME/REPO.git
     git push -u origin main
     ```

2. Pergi ke GitHub -> Repository -> Actions. Workflow `Build SR Trader (Windows)` akan muncul.  
   Klik run atau tunggu push untuk trigger. GitHub Actions akan bina `.exe` (artifact) dan upload ke Actions artifact.  

3. Jika anda mahu code-signing (pilihan), simpan certificate di Secrets: `CSC_LINK` (URL ke pfx in secure storage) and `CSC_KEY_PASSWORD`.

Nota: Pastikan `app/public/config.json` diisi jika guna Finnhub API key (atau set it as a secret and manage in runtime).  

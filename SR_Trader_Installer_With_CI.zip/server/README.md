# Server Proxy Example for SR Trader

This small Node/Express server provides example endpoints you can use as a secure proxy to access market data and place orders.

## Setup
1. Install deps:
```bash
cd server
npm install express body-parser node-fetch@2
node index.js
```

2. Endpoints:
- GET /ping -> health check
- POST /broker/binance/placeOrder -> example endpoint to forward order (simulate)
- GET /market/binance/klines?symbol=BTCUSDT&interval=1m&limit=500 -> fetch historical klines from Binance REST

Security note: Add authentication, validation, rate limiting, input sanitization, and secure storage of API keys before using in production.

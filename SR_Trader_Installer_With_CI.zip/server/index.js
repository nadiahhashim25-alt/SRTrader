/**
 * Simple server proxy example (Node + Express)
 * - Demonstrates endpoints to forward orders to broker REST APIs securely server-side
 * - WARNING: This is an example. Do NOT use in production without adding auth, rate-limits, validation, logging and secure storage.
 */
const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch'); // npm i node-fetch@2
const app = express();
app.use(bodyParser.json());

// health
app.get('/ping', (req, res) => res.json({ ok: true }));

// example Binance order forwarding (server must have API keys in env vars)
app.post('/broker/binance/placeOrder', async (req, res) => {
  // validate input, auth user, etc. (omitted here)
  const order = req.body;
  // In production, sign with API key/secret and send to Binance REST
  // This example just returns the order for demo
  return res.json({ status: 'simulated', order });
});

// example: fetch historical candles from a free REST (like Binance)
app.get('/market/binance/klines', async (req, res) => {
  const { symbol='BTCUSDT', interval='1m', limit=500 } = req.query;
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const r = await fetch(url);
  const j = await r.json();
  // Convert to OHLC objects
  const out = j.map(k => ({ time: Math.floor(k[0]/1000), open: Number(k[1]), high: Number(k[2]), low: Number(k[3]), close: Number(k[4]), volume: Number(k[5]) }));
  res.json(out);
});

const port = process.env.PORT || 4010;
app.listen(port, () => console.log('Server proxy listening on', port));

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow () {
  const win = new BrowserWindow({
    width: 1300,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  // Load the React dev server in dev or the built index.html in production
  const startUrl = process.env.ELECTRON_START_URL || `file://${path.join(__dirname, 'app', 'build', 'index.html')}`;
  win.loadURL(startUrl);

  // Open devtools optionally
  if (process.env.ELECTRON_START_URL) {
    win.webContents.openDevTools({ mode: 'detach' });
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('ping', async () => 'pong');
